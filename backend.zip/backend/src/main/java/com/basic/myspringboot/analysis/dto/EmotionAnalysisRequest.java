package com.basic.myspringboot.analysis.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmotionAnalysisRequest {
    private String content;
}