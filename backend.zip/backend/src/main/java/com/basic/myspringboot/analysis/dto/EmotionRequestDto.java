package com.basic.myspringboot.analysis.dto;

import lombok.AllArgsConstructor;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmotionRequestDto {
    private String content;
}
