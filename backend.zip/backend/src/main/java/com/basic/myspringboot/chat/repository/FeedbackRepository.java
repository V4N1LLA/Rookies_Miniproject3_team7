package com.basic.myspringboot.chat.repository;

import com.basic.myspringboot.chat.entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
}
