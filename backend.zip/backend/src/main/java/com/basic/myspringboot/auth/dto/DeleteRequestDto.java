package com.basic.myspringboot.auth.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class DeleteRequestDto {
    private String password;
}
