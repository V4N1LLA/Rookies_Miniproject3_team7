package com.basic.myspringboot.diary;

public class ForbiddenDiaryException extends RuntimeException {

}